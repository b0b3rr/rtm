var questions = [
  {
    text: "Если человека назвали мордофиля, то это…",
    answers: [
      {
        text: "Значит, что он тщеславный.",
        correct: true,
        explain: "Ну зачем же вы так... В Этимологическом словаре русского языка Макса Фасмера поясняется, что мордофилей называют чванливого человека. Ну а «чванливый» — это высокомерный, тщеславный."
      },
      { text: "Значит, что у него лицо как у хряка.", correct: false },
      { text: "Значит, что чумазый.", correct: false }
    ]
  },
  {
    text: "«Да этот Ярополк — фуфлыга!» Что не так с Ярополком?",
    answers: [
      {
        text: "Он маленький и невзрачный.",
        correct: true,
        explain: "Точно! Словарь Даля говорит, что фуфлыгой называют невзрачного малорослого человека. А еще так называют прыщи."
      },
      { text: "Он тот еще алкоголик.", correct: false },
      { text: "Он не держит свое слово.", correct: false }
    ]
  },
  {
    text: "Если человека прозвали пятигузом, значит, он…",
    answers: [
      {
        text: "Не держит слово.",
        correct: true,
        explain: "Может сесть сразу на пять стульев. Согласно Этимологическому словарю русского языка Макса Фасмера, пятигуз — это ненадежный, непостоянный человек."
      },
      { text: "Изменяет жене", correct: false },
      { text: "Без гроша в кармане.", correct: false }
    ]
  },
  {
    text: "Кто такой шлындра?",
    answers: [
      { text: "Обманщик.", correct: false },
      { text: "Нытик.", correct: false },
      {
        text: "Бродяга.",
        correct: true,
        explain: "Да! В Словаре русского арго «шлындрать» означает бездельничать, шляться."
      }
    ]
  },
  {
    text: "В каком случае про человека можно сказать, что он охренел (в смысле «обнаглел/перешёл границы»), а не просто удивился?",
    answers: [
      {
        text: "Он без спроса берёт твои вещи и делает вид, что так и надо.",
        correct: true,
        explain: "Правильно. Слово «охренел» многозначно, оно означает «обнаглел, потерял совесть»."
      },
      {
        text: "Он в наглую лезет без очереди и ещё возмущается, что его не пропускают.",
        correct: true,
        explain: "Правильно. Слово «охренел» многозначно, оно означает «обнаглел, потерял совесть»."
      },
      { text: "Он съел много хрена и искренне удивился: «Какой жгучий, вот это да!»", correct: false },
      { text: "В осеннем лесу наблюдается завихрение листьев.", correct: false }
    ]
  }
];

var quiz = document.getElementById("quiz");
var finish = document.getElementById("finish");
var statsBox = document.getElementById("stats");

var queue = shuffle(questions);
var currentIndex = 0;
var correctCount = 0;
var locked = false;

function shuffle(array) {
  var copy = array.slice();
  var i, j, temp;
  for (i = copy.length - 1; i > 0; i = i - 1) {
    j = Math.floor(Math.random() * (i + 1));
    temp = copy[i];
    copy[i] = copy[j];
    copy[j] = temp;
  }
  return copy;
}

function showQuestion() {
  if (currentIndex >= queue.length) {
    finishQuiz();
    return;
  }

  var data = queue[currentIndex];

  var row = document.createElement("div");
  row.className = "q-row";

  var qBlock = document.createElement("div");
  qBlock.className = "q-block";

  var num = document.createElement("span");
  num.className = "num";
  num.textContent = currentIndex + 1;

  var qText = document.createElement("span");
  qText.className = "qtext";
  qText.textContent = data.text;

  var marker = document.createElement("span");
  marker.className = "marker";

  qBlock.appendChild(num);
  qBlock.appendChild(qText);
  qBlock.appendChild(marker);

  var answersRow = document.createElement("div");
  answersRow.className = "a-row";

  var shuffledAnswers = shuffle(data.answers);
  var i;
  for (i = 0; i < shuffledAnswers.length; i = i + 1) {
    var answerData = shuffledAnswers[i];

    var a = document.createElement("div");
    a.className = "a-block";

    var aText = document.createElement("span");
    aText.textContent = answerData.text;
    a.appendChild(aText);

    if (answerData.explain) {
      var explain = document.createElement("div");
      explain.className = "explain";
      explain.textContent = answerData.explain;
      a.appendChild(explain);
    }

    a.dataset.correct = answerData.correct ? "1" : "0";

    a.addEventListener("click", makeAnswerHandler(a, answerData, qBlock, answersRow));

    answersRow.appendChild(a);
  }

  row.appendChild(qBlock);
  row.appendChild(answersRow);
  quiz.appendChild(row);

  locked = false;
}

function makeAnswerHandler(answerEl, answerData, qBlock, answersRow) {
  return function () {
    handleAnswer(answerEl, answerData, qBlock, answersRow);
  };
}

function handleAnswer(answerEl, answerData, qBlock, answersRow) {
  if (locked) {
    return;
  }
  locked = true;

  answerEl.classList.add("shake");
  setTimeout(function () {
    answerEl.classList.remove("shake");
  }, 420);

  var allAnswers = answersRow.children;
  var i;
  for (i = 0; i < allAnswers.length; i = i + 1) {
    allAnswers[i].classList.add("disabled");
  }

  var marker = qBlock.querySelector(".marker");

  if (answerData.correct) {
    marker.textContent = "✔";
    marker.style.color = "#3ddc84";
    qBlock.classList.add("correct");
    correctCount = correctCount + 1;
  } else {
    marker.textContent = "✖";
    marker.style.color = "#ff5c7a";
    qBlock.classList.add("wrong");
  }
  marker.classList.add("show");

    if (answerData.correct) {
    for (i = 0; i < allAnswers.length; i = i + 1) {
      if (allAnswers[i].dataset.correct === "1") {
        allAnswers[i].classList.add("correct");
        }
      }
    }



  for (i = 0; i < allAnswers.length; i = i + 1) {
    (function (el, delay) {
      setTimeout(function () {
        el.classList.add("leaving");
      }, delay);
    })(allAnswers[i], 2000 + i * 300);
  }

  var totalDelay = 2000 + allAnswers.length * 300 + 500;

    setTimeout(function () {
    answersRow.innerHTML = "";
    currentIndex = currentIndex + 1;

    if (currentIndex >= queue.length) {
      finishQuiz();
    } else {
      showQuestion();
    }
  }, totalDelay);
}

function finishQuiz() {
  finish.classList.add("show");

  statsBox.innerHTML = "Правильных ответов: <b>" + correctCount + "</b> из <b>" + queue.length + "</b>";
  statsBox.classList.add("show");

  var qBlocks = document.querySelectorAll(".q-block");
  var i;
  for (i = 0; i < qBlocks.length; i = i + 1) {
    qBlocks[i].style.cursor = "pointer";
    qBlocks[i].addEventListener("click", makeRevealHandler(qBlocks[i], i));
  }
}

function makeRevealHandler(qBlock, index) {
  return function () {
    revealCorrect(qBlock, index);
  };
}

function revealCorrect(qBlock, index) {
  var allRows = document.querySelectorAll(".q-row");
  var i;
  for (i = 0; i < allRows.length; i = i + 1) {
    var oldAnswers = allRows[i].querySelector(".a-row");
    if (oldAnswers) {
      oldAnswers.innerHTML = "";
    }
  }

  var data = queue[index];

  var row = qBlock.parentNode;
  var answersRow = row.querySelector(".a-row");

  if (!answersRow) {
    answersRow = document.createElement("div");
    answersRow.className = "a-row";
    row.appendChild(answersRow);
  }

  for (i = 0; i < data.answers.length; i = i + 1) {
    var answerData = data.answers[i];

    if (!answerData.correct) {
      continue;
    }

    var box = document.createElement("div");
    box.className = "a-block correct";

    var boxText = document.createElement("span");
    boxText.textContent = answerData.text;
    box.appendChild(boxText);

    if (answerData.explain) {
      var explain = document.createElement("div");
      explain.className = "explain";
      explain.textContent = answerData.explain;
      box.appendChild(explain);
    }

    answersRow.appendChild(box);
  }
}

showQuestion();